package com.scott.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.hdfs.DistributedFileSystem;
import org.apache.hadoop.yarn.webapp.hamlet2.Hamlet;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;

/*
    客户端常用套路
    1.获取一个客户端对象
    2.执行操作命令
    3.关闭资源
    HDFS zookeeper
*/
public class HDFSClient implements Serializable {

    private FileSystem fs;

    @Before
    public void init() throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI("hdfs://hadoop102:8020");
        Configuration conf = new Configuration();
        conf.set("dfs.replication","2");
        String user = "scott";
        fs = FileSystem.get(uri, conf, user);
    }

    @After
    public void close() throws IOException{
        fs.close();
    }

    @Test
    public void testmkdir() throws IOException {
        fs.mkdirs(new Path("/xiyou/huaguoshan1"));
    }


//    参数优先级排序：（1）客户端代码中设置的值 >（2）ClassPath下的用户自定义配置文件 >
//            （3）然后是服务器的自定义配置（xxx-site.xml） >（4）服务器的默认配置（xxx-default.xml）
    @Test
    public void testPut() throws IOException {
        fs.copyFromLocalFile(false, false, new Path("F:\\study\\99_code\\test\\ccc.txt"), new Path("hdfs://hadoop102:8020/xiyou/huaguoshan"));
    }

//    文件下载
    @Test
    public  void  testGet() throws IOException {
        fs.copyToLocalFile(false, new Path("hdfs://hadoop102:8020/xiyou/huaguoshan/ccc.txt"), new Path("F:\\study\\99_code\\test\\eee.txt"));
    }

    @Test
    public void testRm() throws IOException {
        fs.delete(new Path("hdfs://hadoop102:8020/xiyou/huaguoshan/aaa.txt"), false);
    }

    @Test
    public void testMv() throws IOException {
        fs.rename(new Path("hdfs://hadoop102:8020/xiyou/huaguoshan/bbb.txt"), new Path("hdfs://hadoop102:8020/xiyou/huaguoshan/eee.txt"));
    }

    @Test
    public void fileDetail() throws IOException {
//        获取所有文件信息
        RemoteIterator<LocatedFileStatus> listFiles = fs.listFiles(new Path("/"), true);
        while (listFiles.hasNext()){
            LocatedFileStatus fileStatus = listFiles.next();

            System.out.println("============" + fileStatus.getPath() + "============");
            System.out.println(fileStatus.getPermission());
            System.out.println(fileStatus.getOwner());
            System.out.println(fileStatus.getGroup());
            System.out.println(fileStatus.getLen());
            System.out.println(fileStatus.getModificationTime());
            System.out.println(fileStatus.getReplication());
            System.out.println(fileStatus.getBlockSize());
            System.out.println(fileStatus.getPath().getName());
            BlockLocation[] blockLocations = fileStatus.getBlockLocations();
            System.out.println(Arrays.toString(blockLocations));
        }
    }

    @Test
    public void testFile() throws IOException {
        FileStatus[] listStatus = fs.listStatus((new Path("/")));
        for(FileStatus status : listStatus){
            if(status.isFile()){
                System.out.println("文件： " + status.getPath().getName());
            }else {
                System.out.println("目录： " + status.getPath().getName());
            }

        }
    }

    public static void main(String[] args) {

    }
}
